import os
import pandas as pd

def highlight_cols(x):
    # copy df to new - original data is not changed 
    df = x.copy() 
      
    # select all values to white color 
    df.loc[:, :] = 'background-color: white'
      
    # overwrite values yellow color 
    df[['A', 'C', 'D', 'K']] = 'background-color: yellow'
      
    # return color df 
    return df  

def color(val):
    d = {0:'yellow', 2: 'yellow', 3:'blue'}
    return f'background-color: {d[val]}; color: {d[val]}' if val in d else ''

relevant_path = "."
included_extensions = ['csv']
file_names = [fn for fn in os.listdir(relevant_path)
    if any(fn.endswith(ext) for ext in included_extensions)]
no_files = len(file_names)


for file_name in file_names:
    df = pd.read_csv (file_name)
    total_rows = str(len(df.index))
    print(f"File - {file_name}      rows - {total_rows}")
    file_name_without_ext = file_name.replace(".csv", "")
    if no_files == 1:
        file_nm = "Final Upload.xlsx"
    else:
        file_nm = f"final_{file_name_without_ext}.xlsx"

    writer = pd.ExcelWriter(file_nm, engine = 'xlsxwriter')
    df.to_excel (writer, index = None, header=True, sheet_name='Client File')

    list=[]
    for ind in df.index:
        row_df = {'A':'SI', 'B': df['Account Number'][ind], 'C': 1000, 'D': 1, 'E': df['Document Date'][ind].split(" ")[0], 
            'F': df['Number'][ind], 'G': df['In Use Date From'][ind] + " - " +df['In Use Date To'][ind], 
            'H': df['Charge Total'][ind].astype(float), 'I': 'T1', 'J': df['Charge Total'][ind].astype(float)*0.2, 
            'K': "", 'L': df['Opportunity XO Number'][ind], 'M': df['Owner'][ind]}
        list.append(row_df)
    
    df_out = pd.DataFrame(list)
    st = df_out.style.apply(highlight_cols, axis=None)
    st.to_excel (writer, index = None, header=False, sheet_name='Final Upload')

    writer.close()

